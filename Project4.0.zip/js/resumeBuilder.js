var bio={
    "name":"Harshad Baruah",
    "role": "Web developer",
    "contacts": {
        "mobile": "7002113808",
        "gmail":"harshad_arup@srmuniv.edu.in",
        "twitter":"@dextrocodex",
        "github": "dextrocodex",
        "blog":"HOURSblog",
        "location": "India"
    },
    "welcomeMessage":"To be optimistic in the field of learning and working co-operatively is what defines me. Welcome to my resume!",
    "skills": ["HTML","CSS","C++","Javascript"],
    "bioPic": "images/myself.jpg"
};

var work={
    "jobs":[
        {
            "title":"Systems Engineer",
            "employer":"Infosys India PVT LTD",
            "dates": 2015 + " - "+2017,
            "link": "www.infosysltd.com",
            "origin":"Mysore",
            "description": "Control and maintenance of the system. It includes high performace checks, various Front-end coding and an enjoyable environment to work with. Also working in this position involves maintaining strong relations with every employees and collegues responsibly and collaboratively."
        },
        {
            "title":"Tech Lead",
            "employer":"Infosys India PVT LTD",
            "dates": 2017 + " - "+"present",
            "link": "www.infosysltd.com",
            "origin":"Delhi",
            "description":"Managing technical issues of the system. This means the leading of a group of freshers to build an idea of thorough understanding about different companies' needs and wants. "
        }
    ]
};

var project= {
    "contents": [
        {
            "title": "Active power control of photovoltaic inverters in islanded mode",
            "date": "Jan to May" + " - " +2017,
            "description":"To control the active power of a three phase PV inverter in islanded mode using MPPT  algorithm. It is achieved by incremental conductance method and through vector control of the inverters. The solar power panel absorbs a power ooof near about 100 to 200 KW and transmits to the inverter controlled through incremental conductance MPPT and a boost converter. The inverter than reverses the AC to DC magnitude and stabilizes through vector control. Also frequency stability is achieved through droop control over the whole system This entire system is being designed in MATLAB Simulations.",
            "image": ["images/project.jpg","images/control.png"]
        },
            {"title": "POV display based on Arduino pro mini",
            "date": "Jul to Dec" + " - " +2016,
            "description":"To display Persistence of Vision of different characters and numerals by using LED lights rotation at a high speed monitored by an Arduino pro mini board. The motor rotates at a speed of 500rpm which persists the eyes to visualize an image of what in coded inside the Arduino board. The project is achieved by programming accurate lines of code to the arduino board to give a signal og LED lights flickering within a time lapse of 10-15 msecs. Than the board is connected to a PVC board with resistors and capacitors and connected through 9V batteries. After that a motor of speed 500rpm is connected to rotate the entire board while the flickering lights depict the image.",
            "image": ["images/pov.jpg","images/display.jpg"]
        }
    ]
};

var education= {
    "school":[
        {
            "schoolName": "Maharishi Vidya Mandir",
            "schoolDegree": "Higher secondary qualification",
            "schoolDate": 2011+" - "+2013,
            "schoolLocation" : "Guwahati, "+"Assam",
            "schoolMajor": "Science",
            "linkss": "www.mvm4.org"
        },
        {
            "schoolName": "Maharishi Vidya Mandir",
            "schoolDegree": "High school leaving qualification",
            "schoolDate": 2010+" - "+2011,
            "schoolLocation" : "Guwahati, "+"Assam",
            "schoolMajor": "Class 10",
            "linkss": "www.mvm4.org"
        }
    ]
};

var online= {
    "courses":[
        {
            "title": "Front-end development course",
            "school": "Udacity",
            "dates": 5 + " months ",
            "url": "https://classroom.udacity.com/nanodegrees"
        },
        {
            "title": "Java masterclass course",
            "school": "Udemy",
            "dates": 6 + " months ",
            "url": "https://www.Udemy.com/onlinecourse/classroom"
        }
    ]
};

var formattedName= HTMLheaderName.replace("%data%",bio.name);
var formattedRole= HTMLheaderRole.replace("%data%",bio.role);
$("#header").prepend(formattedRole);
$("#header").prepend(formattedName);

var contact= HTMLmobile.replace("%data%",bio.contacts.mobile);
$("#topContacts").append(contact);
$("#footerContacts").append(contact);
contact= HTMLemail.replace("%data%",bio.contacts.gmail);
$("#topContacts").append(contact);
$("#footerContacts").append(contact);
contact= HTMLtwitter.replace("%data%",bio.contacts.twitter);
$("#topContacts").append(contact);
$("#footerContacts").append(contact);
contact= HTMLgithub.replace("%data%",bio.contacts.github);
$("#topContacts").append(contact);
$("#footerContacts").append(contact);
contact= HTMLblog.replace("%data%",bio.contacts.blog);
$("#topContacts").append(contact);
contact= HTMLlocation.replace("%data%", bio.contacts.location);
$("#topContacts").append(contact);

var pics= HTMLbioPic.replace("%data%",bio.bioPic);
$("#header").append(pics);

var formattedWelcome= HTMLwelcomeMsg.replace("%data%",bio.welcomeMessage);
$("#header").append(formattedWelcome);

if(bio.skills.length>0){
$("#header").append(HTMLskillsStart);
    var formattedSkill= HTMLskills.replace("%data%",bio.skills[0]);
    $("#skills").append(formattedSkill);
    formattedSkill= HTMLskills.replace("%data%",bio.skills[1]);
    $("#skills").append(formattedSkill);
    formattedSkill= HTMLskills.replace("%data%",bio.skills[2]);
    $("#skills").append(formattedSkill);
    formattedSkill= HTMLskills.replace("%data%",bio.skills[3]);
    $("#skills").append(formattedSkill);
}

function displayWork(){
for(var job=0;job<work.jobs.length;job++){
    $("#workExperience").append(HTMLworkStart);

    var formattedEmployer= HTMLworkEmployer.replace("%data%",work.jobs[job].employer).replace("#",work.jobs[job].link);
    var formattedTitle= HTMLworkTitle.replace("%data%",work.jobs[job].title);

    var formatEmpTitle= formattedEmployer + formattedTitle;
    $(".work-entry:last").append(formatEmpTitle);

    var formattedDate= HTMLworkDates.replace("%data%",work.jobs[job].dates);
    $(".work-entry:last").append(formattedDate);
    var formattedLocation= HTMLworkLocation.replace("%data%",work.jobs[job].origin);
    $(".work-entry:last").append(formattedLocation);
    var formattedDescription= HTMLworkDescription.replace("%data%",work.jobs[job].description);
    $(".work-entry:last").append(formattedDescription);
}
}
displayWork();

function projectWork(){
    for(var i=0;i<project.contents.length;i++){
        $("#projects").append(HTMLprojectStart);

        var project10= HTMLprojectTitle.replace("%data%",project.contents[i].title);
        $(".project-entry:last").append(project10);

        var project11= HTMLprojectDates.replace("%data%",project.contents[i].date);
        $(".project-entry:last").append(project11);

        var project12= HTMLprojectDescription.replace("%data%",project.contents[i].description);
        $(".project-entry:last").append(project12);

        if(project.contents[i].image.length>0){
            for(var j=0;j<project.contents[i].image.length;j++){
                var project13= HTMLprojectImage.replace("%data%",project.contents[i].image[j]);
                $(".project-entry:last").append(project13);
            }
        }
    }
}
projectWork();

function displayEducation(){
    for(var classes=0;classes<education.school.length;classes++){
        $("#education").append(HTMLschoolStart);

        var formattedName= HTMLschoolName.replace("%data%",education.school[classes].schoolName).replace("#",education.school[classes].linkss);
        $(".education-entry:last").append(formattedName);
        var formattedDegree= HTMLschoolDegree.replace("%data%",education.school[classes].schoolDegree);
        $(".education-entry:last").append(formattedDegree);
        var formattedDate= HTMLschoolDates.replace("%data%",education.school[classes].schoolDate);
        $(".education-entry:last").append(formattedDate);
        var formattedLocation= HTMLschoolLocation.replace("%data%",education.school[classes].schoolLocation);
        $(".education-entry:last").append(formattedLocation);
        var formattedMajor= HTMLschoolMajor.replace("%data%",education.school[classes].schoolMajor);
        $(".education-entry:last").append(formattedMajor);
    }
    $(".education-entry:last").append(HTMLonlineClasses);
    for(var on=0;on<online.courses.length;on++){
        var courseTitle=HTMLonlineTitle.replace("%data%",online.courses[on].title);
        $(".education-entry:last").append(courseTitle);
        courseSchool= HTMLonlineSchool.replace("%data%",online.courses[on].school);
        $(".education-entry:last").append(courseSchool);
        courseDate= HTMLonlineDates.replace("%data%",online.courses[on].dates);
        $(".education-entry:last").append(courseDate);
        courseURL= HTMLonlineURL.replace("%data%",online.courses[on].url);
        $(".education-entry:last").append(courseURL);
    }
}
displayEducation();

$("#mapDiv").append(googleMap);

$(document).click(function(loc) {
    var x= loc.pageX;
    var y= loc.pageY;
    logClicks(x,y);
});


function inName(name){
    $("#main").append(internationalizeButton);
    name= name.trim().split(" ");
    console.log(name);
    name[1]=name[1].toUpperCase();
    name[0]= name[0].slice(0,1).toUppercase() + name[0].slice(1).toLowerCase();
    return name[0]+ " " + name[1];
}
inName();